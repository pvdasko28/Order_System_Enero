﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BlueKey.CallCenter.WebApp
{
    public partial class Monitor : System.Web.UI.Page
    {
        int contador = 1;
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void Timer1_Tick(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["Cont"] != null)
            {
                contador = int.Parse(HttpContext.Current.Session["Cont"].ToString());
                contador++;
                HttpContext.Current.Session["Cont"] = contador;

            }
            if (contador == 1)
                HttpContext.Current.Session["Cont"] = contador ;

                      

                Label1.Text = "Prueba " + contador.ToString(); 
        }
    }
}