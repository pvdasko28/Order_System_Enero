﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bluekey.CallCenter.BusinessRule;

namespace BlueKey.CallCenter.WebApp
{
    public partial class Home : System.Web.UI.Page
    {
        String St_Mensaje = "";
        string pOrigen = "";
        string pCentral = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            this.txtTel.Attributes.Add("onKeyPress", "return soloNumeros(event);");
            currentTime.InnerText = DateTime.Now.AddHours(1).ToString("T");
            if (!IsPostBack)
            {
                populateCentral();
              
               

            }
            else
            {
                if (HttpContext.Current.Session["sOrigen"] != null)
                    pOrigen = HttpContext.Current.Session["sOrigen"].ToString();

                if (HttpContext.Current.Session["sCentral"] != null)
                    pCentral = HttpContext.Current.Session["sCentral"].ToString();
            }
        }

       

        protected void BtnSen_Click(object sender, EventArgs e)
        {

            try
            {
                Response.Redirect("Cliente.aspx?Corpo=" + txtIdc.Text + "&Central=" + pCentral + "&Ori=" + pOrigen + "&Oper=" + txtOper.Text + "&Tel=" + txtTel.Text);
            }
            catch (Exception Ex)
            {
                String A = Ex.Message;
                String B = Ex.Source;
                St_Mensaje = "Error al enviar parametros para orden \n" + A + "\n" + B;
                lblModalTitle.Text = "Error Order System";
                lblModalBody.Text = St_Mensaje;
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModal').modal();", true);
                upModal.Update();
                throw;
            }

        }

        protected void BtnErr_Click(object sender, EventArgs e)
        {
            lblModalTitle.Text = "Error Order System";
            lblModalBody.Text = "Mensaje de prueba de error";
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "$('#myModal').modal();", true);
            //ScriptManager.RegisterStartupScript(Page, Page.GetType(), "myModal", "myModal.modal('show');", true);
            upModal.Update();
        }

        protected void BtnPedido_Click(object sender, EventArgs e)
        {
            //tarde home
            Response.Redirect("Orden?Corpo=1&Central=potzol&Ori=Cen&Oper=1mx0001&Tel=5575753546&Suc=Cuau%20&IdCli=1&IdDir=1&HoraI=03:57:15%20p.%20m.&rfc=");

            //tarde out 
            //Response.Redirect("Orden?Corpo=1&Central=potzol&Ori=Cen&Oper=1mx0001&Tel=5575753546&Suc=Cuau%20&IdCli=1%20&IdDir=1&HoraI=05:40:17%20p.m.&rfc=");

        }

        private void populateOrigen()
        {
            DataTable tblOri = new DataTable();
            BOS_Central objOri = new BOS_Central();


            objOri.Corporativo = int.Parse( txtIdc.Text);
            objOri.Central = pCentral;
            tblOri = objOri.mgetConsultaOrigen();
            if (tblOri.Rows.Count > 0)
            {

                ddlOri.Items.Clear();
                ddlOri.Items.Add(new ListItem { Text = "Seleccione Origen", Value = "" });
                ddlOri.AppendDataBoundItems = true;
                ddlOri.DataSource = tblOri;
                ddlOri.DataTextField = "NombreOrigen";
                ddlOri.DataValueField = "Origen";
                ddlOri.DataBind();

            }
            else
            {
                ddlOri.Items.Clear();
                ddlOri.Items.Add(new ListItem { Text = "Seleccione Origen", Value = "" });

            }

        }

        protected void ddlOri_SelectedIndexChanged(object sender, EventArgs e)
        {
            pOrigen = ddlOri.SelectedItem.Value.ToString();
            Session["sOrigen"] = pOrigen;
        }

        private void populateCentral()
        {
            DataTable tblCen = new DataTable();
            BOS_Central objCen = new BOS_Central();


            objCen.Corporativo = int.Parse(txtIdc.Text);
            objCen.Central = "";
            tblCen = objCen.mgetConsultaCentral();
            if (tblCen.Rows.Count > 0)
            {

                ddlCen.Items.Clear();
                ddlCen.Items.Add(new ListItem { Text = "Seleccione Central", Value = "" });
                ddlCen.AppendDataBoundItems = true;
                ddlCen.DataSource = tblCen;
                ddlCen.DataTextField = "Nombre Central";
                ddlCen.DataValueField = "Central";
                ddlCen.DataBind();

                ddlOri.Items.Clear();
                ddlOri.Items.Add(new ListItem { Text = "Seleccione Origen", Value = "" });


            }
            else
            {
                ddlCen.Items.Clear();
                ddlCen.Items.Add(new ListItem { Text = "Seleccione Central", Value = "" });

            }

        }

        protected void ddlCen_SelectedIndexChanged(object sender, EventArgs e)
        {
            pCentral = ddlCen.SelectedItem.Value.ToString();
            Session["sCentral"] = pCentral;
            populateOrigen();
        }
    }
}