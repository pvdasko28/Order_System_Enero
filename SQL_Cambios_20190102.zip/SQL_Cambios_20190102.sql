USE [Bluekey_Order_System]
GO
/****** Object:  StoredProcedure [dbo].[bos_sp_platillosnombre]    Script Date: 27/12/2018 04:54:52 p.m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


ALTER PROCEDURE [dbo].[bos_sp_platillosnombre] 
		@Corporativo	bigint,
		@Central		nvarchar (8),
		@Turno			int,
		@NombrePlatillo nvarchar (150),
		@Fecha          nvarchar (10)
		
		
		
AS

	/************************************************************************
	*																		*
	* 						BLUEKEY											*
	*																		*
	*	Objetivo 	: Consulta  platillos por nombre    	 	    		*
	* 	Fecha 		: 20 / Octubre / 2018						    		*
	*	Autor 		: Noe Romero											*
	*																		*
	*	Modif   	: Se agrega fecha proceso para obtener los platillos	*
	* 	Fecha 		: 02 / Enero / 2019						    	    	*
	*	Autor 		: Noe Romero											*
	*																		*	
	************************************************************************/
BEGIN


SET NOCOUNT ON

	DECLARE  @DIA INT

	SELECT @DIA =  DATEPART(dw, CONVERT(DATE, @Fecha, 121))


	--Todos los platillos		
	IF @DIA = 1 
	BEGIN	
		SELECT 
		P.Corporativo,
		P.Central,
		P.Platillo,
		[Nombre Platillo] as NombrePlatillo,
		P.Grupo,
		Clasificacion,
		Servicio,
		Comandera,
		Modificador,
		[Modificador Cantidad] as ModificadorCantidad,
		Terminador,
		Tiempo,
		Precio,
		[Desglosa Servicio] as DesglosaServicio,
		Paquete,
		Promocion,		
		P.Activo
		FROM [dbo].[C_Platillos] P WITH(NOLOCK)
		INNER JOIN [dbo].[C_Turnos Grupos] G WITH(NOLOCK)  ON P.Grupo = G.Grupo 	
		INNER JOIN [dbo].[C_Grupos] T  WITH(NOLOCK)  ON P.Grupo = T.Grupo 	
		WHERE P.Corporativo = @Corporativo
		AND P.Central = @Central		
		AND P.Activo = 1
		AND G.Turno = @Turno
		AND T.Domingo = 1		
		AND [Nombre Platillo] LIKE '%'+ @NombrePlatillo +'%'
		ORDER BY Platillo
	END

	IF  @DIA = 2
	BEGIN	
		SELECT 
		P.Corporativo,
		P.Central,
		P.Platillo,
		[Nombre Platillo] as NombrePlatillo,
		P.Grupo,
		Clasificacion,
		Servicio,
		Comandera,
		Modificador,
		[Modificador Cantidad] as ModificadorCantidad,
		Terminador,
		Tiempo,
		Precio,
		[Desglosa Servicio] as DesglosaServicio,
		Paquete,
		Promocion,		
		P.Activo
		FROM [dbo].[C_Platillos] P WITH(NOLOCK)
		INNER JOIN [dbo].[C_Turnos Grupos] G WITH(NOLOCK)  ON P.Grupo = G.Grupo 	
		INNER JOIN [dbo].[C_Grupos] T  WITH(NOLOCK)  ON P.Grupo = T.Grupo 	
		WHERE P.Corporativo = @Corporativo
		AND P.Central = @Central		
		AND P.Activo = 1
		AND G.Turno = @Turno
		AND T.Lunes = 1		
		AND [Nombre Platillo] LIKE '%'+ @NombrePlatillo +'%'
		ORDER BY Platillo
	END

	IF  @DIA = 3
	BEGIN	
		SELECT 
		P.Corporativo,
		P.Central,
		P.Platillo,
		[Nombre Platillo] as NombrePlatillo,
		P.Grupo,
		Clasificacion,
		Servicio,
		Comandera,
		Modificador,
		[Modificador Cantidad] as ModificadorCantidad,
		Terminador,
		Tiempo,
		Precio,
		[Desglosa Servicio] as DesglosaServicio,
		Paquete,
		Promocion,		
		P.Activo
		FROM [dbo].[C_Platillos] P WITH(NOLOCK)
		INNER JOIN [dbo].[C_Turnos Grupos] G WITH(NOLOCK)  ON P.Grupo = G.Grupo 	
		INNER JOIN [dbo].[C_Grupos] T  WITH(NOLOCK)  ON P.Grupo = T.Grupo 	
		WHERE P.Corporativo = @Corporativo
		AND P.Central = @Central		
		AND P.Activo = 1
		AND G.Turno = @Turno
		AND T.Martes = 1		
		AND [Nombre Platillo] LIKE '%'+ @NombrePlatillo +'%'
		ORDER BY Platillo
	END
	
	IF  @DIA = 4
	BEGIN	
		SELECT 
		P.Corporativo,
		P.Central,
		P.Platillo,
		[Nombre Platillo] as NombrePlatillo,
		P.Grupo,
		Clasificacion,
		Servicio,
		Comandera,
		Modificador,
		[Modificador Cantidad] as ModificadorCantidad,
		Terminador,
		Tiempo,
		Precio,
		[Desglosa Servicio] as DesglosaServicio,
		Paquete,
		Promocion,		
		P.Activo
		FROM [dbo].[C_Platillos] P WITH(NOLOCK)
		INNER JOIN [dbo].[C_Turnos Grupos] G WITH(NOLOCK)  ON P.Grupo = G.Grupo 	
		INNER JOIN [dbo].[C_Grupos] T  WITH(NOLOCK)  ON P.Grupo = T.Grupo 	
		WHERE P.Corporativo = @Corporativo
		AND P.Central = @Central		
		AND P.Activo = 1
		AND G.Turno = @Turno
		AND T.Miercoles = 1		
		AND [Nombre Platillo] LIKE '%'+ @NombrePlatillo +'%'
		ORDER BY Platillo
	END
	
	IF  @DIA = 5
	BEGIN	
		SELECT 
		P.Corporativo,
		P.Central,
		P.Platillo,
		[Nombre Platillo] as NombrePlatillo,
		P.Grupo,
		Clasificacion,
		Servicio,
		Comandera,
		Modificador,
		[Modificador Cantidad] as ModificadorCantidad,
		Terminador,
		Tiempo,
		Precio,
		[Desglosa Servicio] as DesglosaServicio,
		Paquete,
		Promocion,		
		P.Activo
		FROM [dbo].[C_Platillos] P WITH(NOLOCK)
		INNER JOIN [dbo].[C_Turnos Grupos] G WITH(NOLOCK)  ON P.Grupo = G.Grupo 	
		INNER JOIN [dbo].[C_Grupos] T  WITH(NOLOCK)  ON P.Grupo = T.Grupo 	
		WHERE P.Corporativo = @Corporativo
		AND P.Central = @Central		
		AND P.Activo = 1
		AND G.Turno = @Turno
		AND T.Jueves = 1		
		AND [Nombre Platillo] LIKE '%'+ @NombrePlatillo +'%'
		ORDER BY Platillo
	END
	
	IF @DIA = 6
	BEGIN	
		SELECT 
		P.Corporativo,
		P.Central,
		P.Platillo,
		[Nombre Platillo] as NombrePlatillo,
		P.Grupo,
		Clasificacion,
		Servicio,
		Comandera,
		Modificador,
		[Modificador Cantidad] as ModificadorCantidad,
		Terminador,
		Tiempo,
		Precio,
		[Desglosa Servicio] as DesglosaServicio,
		Paquete,
		Promocion,		
		P.Activo
		FROM [dbo].[C_Platillos] P WITH(NOLOCK)
		INNER JOIN [dbo].[C_Turnos Grupos] G WITH(NOLOCK)  ON P.Grupo = G.Grupo 	
		INNER JOIN [dbo].[C_Grupos] T  WITH(NOLOCK)  ON P.Grupo = T.Grupo 	
		WHERE P.Corporativo = @Corporativo
		AND P.Central = @Central		
		AND P.Activo = 1
		AND G.Turno = @Turno
		AND T.Viernes = 1		
		AND [Nombre Platillo] LIKE '%'+ @NombrePlatillo +'%'
		ORDER BY Platillo
	END

	IF  @DIA = 7
	BEGIN	
		SELECT 
		P.Corporativo,
		P.Central,
		P.Platillo,
		[Nombre Platillo] as NombrePlatillo,
		P.Grupo,
		Clasificacion,
		Servicio,
		Comandera,
		Modificador,
		[Modificador Cantidad] as ModificadorCantidad,
		Terminador,
		Tiempo,
		Precio,
		[Desglosa Servicio] as DesglosaServicio,
		Paquete,
		Promocion,		
		P.Activo
		FROM [dbo].[C_Platillos] P WITH(NOLOCK)
		INNER JOIN [dbo].[C_Turnos Grupos] G WITH(NOLOCK)  ON P.Grupo = G.Grupo 	
		INNER JOIN [dbo].[C_Grupos] T  WITH(NOLOCK)  ON P.Grupo = T.Grupo 	
		WHERE P.Corporativo = @Corporativo
		AND P.Central = @Central		
		AND P.Activo = 1
		AND G.Turno = @Turno
		AND T.Sabado = 1		
		AND [Nombre Platillo] LIKE '%'+ @NombrePlatillo +'%'
		ORDER BY Platillo
	END
	
	
END

GO

/****** Object:  StoredProcedure [dbo].[bos_sp_turnosgrupos]    Script Date: 27/12/2018 12:35:50 p.m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[bos_sp_turnosgrupos] 
		@Corporativo	bigint,
		@Central		nvarchar (8),
		@Turno   		bigint,
		@Fecha          nvarchar (10)
		
AS

	/************************************************************************
	*																		*
	* 						BLUEKEY											*
	*																		*
	*	Objetivo 	: Consulta turnos grupos				 	    		*
	* 	Fecha 		: 16 / Octubre / 2018						    		*
	*	Autor 		: Noe Romero											*
	*																		*
	*	Modif   	: Se agrega fecha proceso para obtener los platillos	*
	* 	Fecha 		: 02 / Enero / 2019						    	    	*
	*	Autor 		: Noe Romero											*
	*																		*		
	************************************************************************/
BEGIN

SET NOCOUNT ON

	DECLARE  @Dia INT

	SELECT @Dia =  DATEPART(dw, CONVERT(DATE, @Fecha, 121))

	IF  @Dia = 1 
	BEGIN
		SELECT 
		T.Corporativo,
		T.Central,
		T.Turno,
		T.Orden,
		T.Grupo,
		G.[Nombre Grupo] as NombreGrupo
		FROM [dbo].[C_Turnos Grupos] T WITH(NOLOCK) 
		INNER JOIN [dbo].[C_Grupos] G  WITH(NOLOCK)  ON T.Grupo = G.Grupo 
		WHERE T.Corporativo = @Corporativo
		AND T.Central = @Central
		AND T.Turno = @Turno
		AND G.Domingo = 1		
		ORDER BY Orden

	END

	IF  @Dia = 2
	BEGIN
		SELECT 
		T.Corporativo,
		T.Central,
		T.Turno,
		T.Orden,
		T.Grupo,
		G.[Nombre Grupo] as NombreGrupo
		FROM [dbo].[C_Turnos Grupos] T WITH(NOLOCK) 
		INNER JOIN [dbo].[C_Grupos] G  WITH(NOLOCK)  ON T.Grupo = G.Grupo 
		WHERE T.Corporativo = @Corporativo
		AND T.Central = @Central
		AND T.Turno = @Turno
		AND G.Lunes = 1		
		ORDER BY Orden

	END

	IF  @Dia = 3
	BEGIN
		SELECT 
		T.Corporativo,
		T.Central,
		T.Turno,
		T.Orden,
		T.Grupo,
		G.[Nombre Grupo] as NombreGrupo
		FROM [dbo].[C_Turnos Grupos] T WITH(NOLOCK) 
		INNER JOIN [dbo].[C_Grupos] G  WITH(NOLOCK)  ON T.Grupo = G.Grupo 
		WHERE T.Corporativo = @Corporativo
		AND T.Central = @Central
		AND T.Turno = @Turno
		AND G.Martes = 1		
		ORDER BY Orden

	END

	IF  @Dia = 4
	BEGIN
		SELECT 
		T.Corporativo,
		T.Central,
		T.Turno,
		T.Orden,
		T.Grupo,
		G.[Nombre Grupo] as NombreGrupo
		FROM [dbo].[C_Turnos Grupos] T WITH(NOLOCK) 
		INNER JOIN [dbo].[C_Grupos] G  WITH(NOLOCK)  ON T.Grupo = G.Grupo 
		WHERE T.Corporativo = @Corporativo
		AND T.Central = @Central
		AND T.Turno = @Turno
		AND G.Miercoles = 1		
		ORDER BY Orden

	END

	IF  @Dia = 5
	BEGIN
		SELECT 
		T.Corporativo,
		T.Central,
		T.Turno,
		T.Orden,
		T.Grupo,
		G.[Nombre Grupo] as NombreGrupo
		FROM [dbo].[C_Turnos Grupos] T WITH(NOLOCK) 
		INNER JOIN [dbo].[C_Grupos] G  WITH(NOLOCK)  ON T.Grupo = G.Grupo 
		WHERE T.Corporativo = @Corporativo
		AND T.Central = @Central
		AND T.Turno = @Turno
		AND G.Jueves = 1		
		ORDER BY Orden

	END

	IF  @Dia = 6
	BEGIN
		SELECT 
		T.Corporativo,
		T.Central,
		T.Turno,
		T.Orden,
		T.Grupo,
		G.[Nombre Grupo] as NombreGrupo
		FROM [dbo].[C_Turnos Grupos] T WITH(NOLOCK) 
		INNER JOIN [dbo].[C_Grupos] G  WITH(NOLOCK)  ON T.Grupo = G.Grupo 
		WHERE T.Corporativo = @Corporativo
		AND T.Central = @Central
		AND T.Turno = @Turno
		AND G.Viernes = 1		
		ORDER BY Orden

	END

	IF  @Dia = 7
	BEGIN
		SELECT 
		T.Corporativo,
		T.Central,
		T.Turno,
		T.Orden,
		T.Grupo,
		G.[Nombre Grupo] as NombreGrupo
		FROM [dbo].[C_Turnos Grupos] T WITH(NOLOCK) 
		INNER JOIN [dbo].[C_Grupos] G  WITH(NOLOCK)  ON T.Grupo = G.Grupo 
		WHERE T.Corporativo = @Corporativo
		AND T.Central = @Central
		AND T.Turno = @Turno
		AND G.Sabado = 1		
		ORDER BY Orden

	END

	

END

GO
/****** Object:  StoredProcedure [dbo].[bos_sp_turnosplatillo]    Script Date: 27/12/2018 04:59:26 p.m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[bos_sp_turnosplatillo] 
		@Corporativo	bigint,
		@Central		nvarchar (8),
		@Turno   		bigint,
		@Fecha			nvarchar (10)
		
AS

	/************************************************************************
	*																		*
	* 						BLUEKEY											*
	*																		*
	*	Objetivo 	: Consulta turnos platillo				 	    		*
	* 	Fecha 		: 16 / Octubre / 2018						    		*
	*	Autor 		: Noe Romero											*
	*																		*
	*	Modif   	: Se agrega fecha proceso para obtener los platillos	*
	* 	Fecha 		: 02 / Enero / 2019						    	    	*
	*	Autor 		: Noe Romero											*
	*																		*		
	************************************************************************/
BEGIN

SET NOCOUNT ON

	
	DECLARE  @Dia INT

	SELECT @Dia =  DATEPART(dw, CONVERT(DATE, @Fecha, 121))
	
	IF  @Dia = 1 
	BEGIN		
		SELECT 
		T.Corporativo,
		T.Central,
		T.Turno,
		T.Orden,
		T.Platillo,		
		P.[Nombre Platillo] AS NombrePlatillo		
		FROM [dbo].[C_Turnos Platillos] T WITH(NOLOCK) 
		INNER JOIN [dbo].[C_Platillos] P WITH(NOLOCK)  ON T.Platillo = P.Platillo
		INNER JOIN [dbo].[C_Grupos] G  WITH(NOLOCK)  ON P.Grupo = G.Grupo 
		WHERE T.Corporativo = @Corporativo
		AND T.Central = @Central
		AND T.Turno = @Turno
		AND G.Domingo = 1	
		ORDER BY T.Orden

	END

	IF  @Dia = 2 
	BEGIN		
		SELECT 
		T.Corporativo,
		T.Central,
		T.Turno,
		T.Orden,
		T.Platillo,		
		P.[Nombre Platillo] AS NombrePlatillo		
		FROM [dbo].[C_Turnos Platillos] T WITH(NOLOCK) 
		INNER JOIN [dbo].[C_Platillos] P WITH(NOLOCK)  ON T.Platillo = P.Platillo
		INNER JOIN [dbo].[C_Grupos] G  WITH(NOLOCK)  ON P.Grupo = G.Grupo 
		WHERE T.Corporativo = @Corporativo
		AND T.Central = @Central
		AND T.Turno = @Turno
		AND G.Lunes = 1	
		ORDER BY T.Orden

	END


	IF  @Dia = 3
	BEGIN		
		SELECT 
		T.Corporativo,
		T.Central,
		T.Turno,
		T.Orden,
		T.Platillo,		
		P.[Nombre Platillo] AS NombrePlatillo		
		FROM [dbo].[C_Turnos Platillos] T WITH(NOLOCK) 
		INNER JOIN [dbo].[C_Platillos] P WITH(NOLOCK)  ON T.Platillo = P.Platillo
		INNER JOIN [dbo].[C_Grupos] G  WITH(NOLOCK)  ON P.Grupo = G.Grupo 
		WHERE T.Corporativo = @Corporativo
		AND T.Central = @Central
		AND T.Turno = @Turno
		AND G.Martes = 1	
		ORDER BY T.Orden

	END
	
	IF  @Dia = 4
	BEGIN		
		SELECT 
		T.Corporativo,
		T.Central,
		T.Turno,
		T.Orden,
		T.Platillo,		
		P.[Nombre Platillo] AS NombrePlatillo		
		FROM [dbo].[C_Turnos Platillos] T WITH(NOLOCK) 
		INNER JOIN [dbo].[C_Platillos] P WITH(NOLOCK)  ON T.Platillo = P.Platillo
		INNER JOIN [dbo].[C_Grupos] G  WITH(NOLOCK)  ON P.Grupo = G.Grupo 
		WHERE T.Corporativo = @Corporativo
		AND T.Central = @Central
		AND T.Turno = @Turno
		AND G.Miercoles = 1	
		ORDER BY T.Orden

	END

	IF  @Dia = 5
	BEGIN		
		SELECT 
		T.Corporativo,
		T.Central,
		T.Turno,
		T.Orden,
		T.Platillo,		
		P.[Nombre Platillo] AS NombrePlatillo		
		FROM [dbo].[C_Turnos Platillos] T WITH(NOLOCK) 
		INNER JOIN [dbo].[C_Platillos] P WITH(NOLOCK)  ON T.Platillo = P.Platillo
		INNER JOIN [dbo].[C_Grupos] G  WITH(NOLOCK)  ON P.Grupo = G.Grupo 
		WHERE T.Corporativo = @Corporativo
		AND T.Central = @Central
		AND T.Turno = @Turno
		AND G.Jueves = 1	
		ORDER BY T.Orden

	END

	IF  @Dia = 6
	BEGIN		
		SELECT 
		T.Corporativo,
		T.Central,
		T.Turno,
		T.Orden,
		T.Platillo,		
		P.[Nombre Platillo] AS NombrePlatillo		
		FROM [dbo].[C_Turnos Platillos] T WITH(NOLOCK) 
		INNER JOIN [dbo].[C_Platillos] P WITH(NOLOCK)  ON T.Platillo = P.Platillo
		INNER JOIN [dbo].[C_Grupos] G  WITH(NOLOCK)  ON P.Grupo = G.Grupo 
		WHERE T.Corporativo = @Corporativo
		AND T.Central = @Central
		AND T.Turno = @Turno
		AND G.Viernes = 1	
		ORDER BY T.Orden

	END

	IF  @Dia = 7
	BEGIN		
		SELECT 
		T.Corporativo,
		T.Central,
		T.Turno,
		T.Orden,
		T.Platillo,		
		P.[Nombre Platillo] AS NombrePlatillo		
		FROM [dbo].[C_Turnos Platillos] T WITH(NOLOCK) 
		INNER JOIN [dbo].[C_Platillos] P WITH(NOLOCK)  ON T.Platillo = P.Platillo
		INNER JOIN [dbo].[C_Grupos] G  WITH(NOLOCK)  ON P.Grupo = G.Grupo 
		WHERE T.Corporativo = @Corporativo
		AND T.Central = @Central
		AND T.Turno = @Turno
		AND G.Sabado = 1	
		ORDER BY T.Orden

	END
	
	

END





