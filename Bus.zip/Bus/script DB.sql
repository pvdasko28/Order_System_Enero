CREATE DATABASE [Reservaciones] 
GO
ALTER DATABASE Reservaciones MODIFY FILE 
( NAME = N'Reservaciones' , SIZE = 3048KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
GO
ALTER DATABASE Reservaciones MODIFY FILE 
( NAME = N'Reservaciones_log' , SIZE = 1024KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO
USE [Reservaciones] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Asientos](
	[IdAsiento] [int] NOT NULL,
	[IdPasajeros] [int]  NULL,
	[Ocupado] [bit]  NULL
 CONSTRAINT [PK_Asientos] PRIMARY KEY CLUSTERED 
(
	[IdAsiento] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Pasajeros](
	[IdPasajero] [int] NOT NULL,
	[NombrePasajero] [nvarchar](100) NOT NULL,
	[IdAsiento] [int] NOT NULL,
 CONSTRAINT [PK_Pasajeros] PRIMARY KEY CLUSTERED 
(
	[IdPasajero] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

--GO
--ALTER TABLE [dbo].[Asientos]  WITH CHECK ADD  CONSTRAINT [FK_Asientos_Pasajeros] FOREIGN KEY([IdPasajeros])
--REFERENCES [dbo].[Pasajeros] ([IdPasajero])
--GO
--ALTER TABLE [dbo].[Asientos] CHECK CONSTRAINT [FK_Asientos_Pasajeros]
GO
ALTER TABLE [dbo].[Pasajeros]  WITH CHECK ADD  CONSTRAINT [FK_Pasajeros_Asientos] FOREIGN KEY([IdAsiento])
REFERENCES [dbo].[Asientos] ([IdAsiento])
GO
ALTER TABLE [dbo].[Pasajeros] CHECK CONSTRAINT [FK_Pasajeros_Asientos]
GO


DECLARE  @Asiento INT

SELECT @Asiento= 1

WHILE (@Asiento < 41)
BEGIN  
   
   INSERT INTO [dbo].[Asientos]
   SELECT @Asiento, null , 0

   SET @Asiento  = @Asiento +1
END  

GO