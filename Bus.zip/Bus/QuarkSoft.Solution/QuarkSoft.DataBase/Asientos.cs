using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace QuarkSoft.Models
{
    
    public  class Asientos
    {
        public Asientos()
        {
            this.Pasajeros = new HashSet<Pasajeros>();
        }
    
        [Key]
        public int IdAsiento { get; set; }
        public Nullable<int> IdPasajeros { get; set; }
        public Nullable<bool> Ocupado { get; set; }
            
        public virtual ICollection<Pasajeros> Pasajeros { get; set; }
    }
}
