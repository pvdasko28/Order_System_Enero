using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace QuarkSoft.Models
{    
    public  class Pasajeros
    {
        [Key]
        public int IdPasajero { get; set; }
        public string NombrePasajero { get; set; }
        public int IdAsiento { get; set; }
    
        public virtual Asientos Asientos { get; set; }
    }
}
