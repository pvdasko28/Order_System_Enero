﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace QuarkSoft.WebApp.Models
{
    public class ReservacionesContext : DbContext    
    {

        public ReservacionesContext()
            : base("name=ReservacionesConnString")
        {
        }
    
        //protected override void OnModelCreating(DbModelBuilder modelBuilder)
        //{
        //    throw new UnintentionalCodeFirstException();
        //}
    
        public  DbSet<Asientos> Asientos { get; set; }
        public  DbSet<Pasajeros> Pasajeros { get; set; }
    }
}