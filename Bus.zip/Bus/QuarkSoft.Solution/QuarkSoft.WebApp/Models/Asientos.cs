﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace QuarkSoft.WebApp.Models
{


    public class Asientos
    {
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Asientos()
        {
            this.Pasajeros = new HashSet<Pasajeros>();
        }

        [Key]
        public int IdAsiento { get; set; }
        public int IdPasajeros { get; set; }
        public bool Ocupado { get; set; }

        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Pasajeros> Pasajeros { get; set; }
    }
}
