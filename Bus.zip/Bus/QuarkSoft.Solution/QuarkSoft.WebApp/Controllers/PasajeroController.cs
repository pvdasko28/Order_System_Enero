﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QuarkSoft.WebApp.Controllers
{
    public class PasajeroController : Controller
    {
        private Models.ReservacionesContext db = new Models.ReservacionesContext();
        
        // GET: Pasajero
        public ActionResult Index()
        {
           

            var viewModel = from p in db.Pasajeros
                            select p;

            return View (viewModel);

        }

        public ActionResult Create()
        {
           
                var viewModel = from p in db.Pasajeros
                                select p;

                PopulateAsientos();
                return View(viewModel);
           

            
        }


        private void PopulateAsientos(object selectedAsiento= null)
        {
            var asientosQuery = from d in db.Asientos
                                   orderby d.IdAsiento
                                   select d;
            ViewBag.IdAsiento = new SelectList(asientosQuery, "IdAsiento", "Ocupado", selectedAsiento);
        }


    }
}