﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;


namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_CodigoPostal
    {
        private string _errorMessage;
        private string _errorSource;

        public long Corporativo { get; set; }
        public string CodigoPostal { get; set; }
        public string  Estado { get; set; }
        public string Municipio { get; set; }
        public string Colonia { get; set; }
        public int Opcion { get; set; }

        #region public methods

        public DataTable mgetConsultaCodigoPostal()
        {
            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[5];
                parameters[0] = new SqlParameter("@Opcion", this.Opcion);
                parameters[1] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[2] = new SqlParameter("@Codigopostal", this.CodigoPostal);
                parameters[3] = new SqlParameter("@Estado", this.Estado);
                parameters[4] = new SqlParameter("@Municipio", this.Municipio);
                dset = dao.ExecuteDataSet("bos_sp_codigopostal", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                throw;
            }
            return dtable;


        }

        #endregion

    }
}
