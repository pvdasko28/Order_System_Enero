﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Grupo
    {
        private string _errorMessage;
        private string _errorSource;

        public long Corporativo { get; set; }
      
        public string Central { get; set; }
       
        public long Grupo { get; set; }
        
        public string Nombre_Grupo { get; set; }
        
        public string Color { get; set; }

        public bool Lunes { get; set; }

        public bool Martes { get; set; }

        public bool Miercoles { get; set; }

        public bool Jueves { get; set; }

        public bool Viernes { get; set; }

        public bool Sabado { get; set; }

        public bool Domingo { get; set; }

        public bool Activo { get; set; }

        #region public methods

        public DataTable mgetConsultaGrupos()
        {

            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@Central", this.Central);
                parameters[2] = new SqlParameter("@Grupo", this.Grupo);
                dset = dao.ExecuteDataSet("bos_sp_grupos", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                throw;

            }
            return dtable;
        }
        #endregion
    }
}
