﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Cliente
    {
        private string _errorMessage;
        private string _errorSource;

        public long Corporativo { get; set; }

        public long Id_Cliente { get; set; }

    
        public string Telefono_Cliente { get; set; }

        
        public string Telefono_Celular { get; set; }

      
        public string Telefono_Extra { get; set; }

        
        public string Nombre { get; set; }

       
        public string Apellido { get; set; }

        
        public string Email { get; set; }

      
        public string Fecha_Nacimiento { get; set; }

        public int Opcion { get; set; }

        public string Filtro { get; set; }

        #region publicMethods

        public DataTable mgetConsultaClienteDirecciones()
        {
            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();
          
            try
            {
                SqlParameter[] parameters = new SqlParameter[4];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@Telefono", this.Telefono_Cliente);
                parameters[2] = new SqlParameter("@Opcion", this.Opcion);
                parameters[3] = new SqlParameter("@Filtro", this.Filtro);
                dset = dao.ExecuteDataSet("bos_sp_clientesdirecciones", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch (Exception ex )
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;               
                throw;

            }
            return dtable;


        }
        

        public int insertaCliente()
        {
            int returnValue = 0;

            try
            {
                DataAccess dao = new DataAccess();

                SqlParameter[] parameters = new SqlParameter[8];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@TelefonoCliente", this.Telefono_Cliente);
                parameters[2] = new SqlParameter("@TelefonoCelular", this.Telefono_Celular);
                parameters[3] = new SqlParameter("@TelefonoExtra", this.Telefono_Extra);
                parameters[4] = new SqlParameter("@Nombre", this.Nombre);
                parameters[5] = new SqlParameter("@Apellido", this.Apellido);
                parameters[6] = new SqlParameter("@Email", this.Email);
                parameters[7] = new SqlParameter("@FechaNacimiento", this.Fecha_Nacimiento);    
                SqlParameter paramReturn = new SqlParameter("@IdCliente", 0);
                paramReturn.Direction = System.Data.ParameterDirection.Output;
                dao.ExecuteNonQuery("bos_spi_clientes", parameters, paramReturn);
                returnValue = int.Parse(paramReturn.Value.ToString());

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                returnValue = 0;              
            }
            return returnValue;
        }

        public int actualizaCliente()
        {
            int returnValue = 0;

            try
            {
                DataAccess dao = new DataAccess();

                SqlParameter[] parameters = new SqlParameter[9];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@IdCliente", this.Id_Cliente);
                parameters[2] = new SqlParameter("@TelefonoCliente", this.Telefono_Cliente);
                parameters[3] = new SqlParameter("@TelefonoCelular", this.Telefono_Celular);
                parameters[4] = new SqlParameter("@TelefonoExtra", this.Telefono_Extra);
                parameters[5] = new SqlParameter("@Nombre", this.Nombre);
                parameters[6] = new SqlParameter("@Apellido", this.Apellido);
                parameters[7] = new SqlParameter("@Email", this.Email);
                parameters[8] = new SqlParameter("@FechaNacimiento", this.Fecha_Nacimiento);
                returnValue = dao.ExecuteNonQuery("bos_spu_clientes", parameters);
              

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                returnValue = 0;
            }
            return returnValue;
        }

        #endregion

    }
}
