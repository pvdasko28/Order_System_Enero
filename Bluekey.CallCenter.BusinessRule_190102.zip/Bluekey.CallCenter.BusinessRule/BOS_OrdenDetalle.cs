﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_OrdenDetalle
    {
        private string _errorMessage;
        private string _errorSource;

        public long Corporativo { get; set; }
        public string Central { get; set; }
        public long Orden { get; set; }
        public int Linea { get; set; }
        public int Platillo { get; set; }
        public string Nombre_Platillo { get; set; }
        public int Linea_Paquete { get; set; }
        public int Comensal { get; set; }
        public double Cantidad { get; set; }
        public decimal Precio { get; set; }
        public string Nota_Platillo { get; set; }
        public bool NotVisible { get; set; }
        public int Terminador { get; set; }
        public decimal Precio_Neto { get; set; }
        public decimal Servicio { get; set; }
        public decimal Descuento { get; set; }
        public double Descuento_Porcentaje { get; set; }
        public string Fecha_Captura_Platillo { get; set; }
        public bool Activo { get; set; }
        public string Usuario_Cancela { get; set; }
        public string Fecha_Cancela { get; set; }
        public string Nota_Cancela { get; set; }       
        public bool Botones { get; set; }
        public string Desc_Terminador { get; set; }
        public bool TermVisible { get; set; }
        public string Desc_Modificador { get; set; }
        public bool ModVisible { get; set; }
        public int Linea_Promocion { get; set; } 
        public string Clasificacion { get; set; }
        public bool NoPregunta { get; set; }



        public int insertaOrdenDetalle()
        {

            int returnValue = 0;

            try
            {
                DataAccess dao = new DataAccess();

                SqlParameter[] parameters = new SqlParameter[21];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@Central", this.Central);
                parameters[2] = new SqlParameter("@Orden", this.Orden);
                parameters[3] = new SqlParameter("@Linea", this.Linea);
                parameters[4] = new SqlParameter("@Platillo", this.Platillo);
                parameters[5] = new SqlParameter("@NombrePlatillo", Nombre_Platillo);
                parameters[6] = new SqlParameter("@LineaPaquete", Linea_Paquete);
                parameters[7] = new SqlParameter("@Comensal", this.Comensal);
                parameters[8] = new SqlParameter("@Cantidad", this.Cantidad);
                parameters[9] = new SqlParameter("@Precio", this.Precio);
                parameters[10] = new SqlParameter("@NotaPlatillo", this.Nota_Platillo);
                parameters[11] = new SqlParameter("@Terminador", this.Terminador);
                parameters[12] = new SqlParameter("@PrecioNeto", this.Precio_Neto);
                parameters[13] = new SqlParameter("@Servicio", this.Servicio);
                parameters[14] = new SqlParameter("@Descuento", this.Descuento);
                parameters[15] = new SqlParameter("@DescuentoPorcentaje",this.Descuento_Porcentaje);
                parameters[16] = new SqlParameter("@FechaCapturaPlatillo", this.Fecha_Captura_Platillo);
                parameters[17] = new SqlParameter("@Activo", this.Activo);
                parameters[18] = new SqlParameter("@UsuarioCancela", this.Usuario_Cancela);
                parameters[19] = new SqlParameter("@FechaCancela", this.Fecha_Cancela);
                parameters[20] = new SqlParameter("@NotaCancela", this.Nota_Cancela);                
               returnValue = dao.ExecuteNonQuery("bos_spi_ordenesdetalle", parameters);                

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                returnValue = 0;
            }
            return returnValue;
        }
    }
}
