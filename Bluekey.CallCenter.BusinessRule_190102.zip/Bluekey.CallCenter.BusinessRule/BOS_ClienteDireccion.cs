﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_ClienteDireccion
    {
        private string _errorMessage;
        private string _errorSource;

        public long Corporativo { get; set; }

       
        public long Id_Cliente { get; set; }

      
        public int Id_Direccion { get; set; }

        public string Residencia { get; set; }

        public string Codigo_Postal { get; set; }

       
        public string Calle { get; set; }

       
        public string No_Exterior { get; set; }

        
        public string No_Interior { get; set; }

       
        public string Colonia { get; set; }

       
        public string Municipio { get; set; }

      
        public string Estado { get; set; }

       
        public string Entre_Calles { get; set; }

      
        public string Referencia { get; set; }

        #region public methods
        public DataTable mgetConsultaClienteDireccion()
        {
            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@IdCliente", this.Id_Cliente);
                parameters[2] = new SqlParameter("@IdDireccion", this.Id_Direccion);
                dset = dao.ExecuteDataSet("bos_sp_clientedireccion", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                throw;

            }
            return dtable;


        }

        public int insertaClienteDireccion()
        {
            int  returnValue = 0;

            try
            {
                DataAccess dao = new DataAccess();

                SqlParameter[] parameters = new SqlParameter[12];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@IdCliente", this.Id_Cliente);
                parameters[2] = new SqlParameter("@Residencia", this.Residencia);
                parameters[3] = new SqlParameter("@CodigoPostal", this.Codigo_Postal);
                parameters[4] = new SqlParameter("@Calle", this.Calle);
                parameters[5] = new SqlParameter("@NoExterior", this.No_Exterior);
                parameters[6] = new SqlParameter("@NoInterior", this.No_Interior);
                parameters[7] = new SqlParameter("@Colonia", this.Colonia);
                parameters[8] = new SqlParameter("@Municipio", this.Municipio);
                parameters[9] = new SqlParameter("@Estado", this.Estado);
                parameters[10] = new SqlParameter("@EntreCalles", this.Entre_Calles);
                parameters[11] = new SqlParameter("@Referencia", this.Referencia);

                SqlParameter paramReturn = new SqlParameter("@IdDireccion", 0);
                paramReturn.Direction = System.Data.ParameterDirection.Output;
                dao.ExecuteNonQuery("bos_spi_clientesdirecciones", parameters, paramReturn);
                returnValue = int.Parse(paramReturn.Value.ToString());


            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                returnValue = 0;             
            }
            return returnValue;
        }


        public int actualizaClienteDireccion()
        {
            int returnValue = 0;

            try
            {
                DataAccess dao = new DataAccess();

                SqlParameter[] parameters = new SqlParameter[13];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@IdCliente", this.Id_Cliente);
                parameters[2] = new SqlParameter("@IdDireccion", this.Id_Direccion);
                parameters[3] = new SqlParameter("@Residencia", this.Residencia);
                parameters[4] = new SqlParameter("@CodigoPostal", this.Codigo_Postal);
                parameters[5] = new SqlParameter("@Calle", this.Calle);
                parameters[6] = new SqlParameter("@NoExterior", this.No_Exterior);
                parameters[7] = new SqlParameter("@NoInterior", this.No_Interior);
                parameters[8] = new SqlParameter("@Colonia", this.Colonia);
                parameters[9] = new SqlParameter("@Municipio", this.Municipio);
                parameters[10] = new SqlParameter("@Estado", this.Estado);
                parameters[11] = new SqlParameter("@EntreCalles", this.Entre_Calles);
                parameters[12] = new SqlParameter("@Referencia", this.Referencia);

                returnValue= dao.ExecuteNonQuery("bos_spu_clientesdirecciones", parameters);
             


            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                returnValue = 0;
            }
            return returnValue;
        }
        #endregion

    }
}
