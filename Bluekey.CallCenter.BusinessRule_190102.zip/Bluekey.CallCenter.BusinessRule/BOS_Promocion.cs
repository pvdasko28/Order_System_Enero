﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bluekey.CallCenter.DataAcces;

namespace Bluekey.CallCenter.BusinessRule
{
    public class BOS_Promocion
    {

        private string _errorMessage;
        private string _errorSource;

        public long Corporativo { get; set; }
                
        public string Central { get; set; }
        
        public long Platillo { get; set; }
                
        public long Platillo_Promocion { get; set; }

        public int Cantidad { get; set; }
        
        public decimal Importe { get; set; }
                
        public DateTime? Fecha_Inicial { get; set; }
          
        public DateTime? Fecha_Final { get; set; }

        public bool Reemplaza { get; set; }

        public bool Pregunta { get; set; }

        public string Fecha_Proceso { get; set; }

        public string Clasificacion { get; set; }


        #region public methods

        public DataTable mgetConsultaPromocion()
        {
            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[4];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@Central", this.Central);
                parameters[2] = new SqlParameter("@Platillo", this.Platillo);
                parameters[3] = new SqlParameter("@FechaProceso", this.Fecha_Proceso);
                dset = dao.ExecuteDataSet("bos_sp_promocion", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                throw;
            }
            return dtable;


        }


        public DataTable mgetConsultaReemplazos()
        {
            DataAccess dao = new DataAccess();
            DataSet dset = new DataSet();
            DataTable dtable = new DataTable();

            try
            {
                SqlParameter[] parameters = new SqlParameter[4];
                parameters[0] = new SqlParameter("@Corporativo", this.Corporativo);
                parameters[1] = new SqlParameter("@Central", this.Central);
                parameters[2] = new SqlParameter("@Platillo", this.Platillo);
                parameters[3] = new SqlParameter("@Clasificacion", this.Clasificacion);
                dset = dao.ExecuteDataSet("bos_sp_reemplazos", parameters);
                if (dset.Tables.Count > 0)
                    dtable = dset.Tables[0];

            }
            catch (Exception ex)
            {
                _errorMessage = ex.Message;
                _errorSource = ex.Source;
                throw;
            }
            return dtable;


        }

        #endregion

    }
}
